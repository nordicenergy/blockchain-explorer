module.exports = {
  baseUrl: process.env.BASE_URL
};
