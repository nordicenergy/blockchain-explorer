export default {
  '54084': {
    name: 'PowerChain Testnet',
    manager: 'http://40.113.129.13:22004',
    rpc: 'http://40.113.129.13:22000/',
  },
  '78377': {
    name: 'PowerChain Prod',
    manager: 'http://40.113.129.13:32004',
    rpc: 'http://40.113.129.13:32000/',
  },
};
